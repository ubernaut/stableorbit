import sys
sys.path.append('./lib')
from system import *
from planetarium import *
